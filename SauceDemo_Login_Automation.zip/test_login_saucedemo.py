# test_login_saucedemo.py

from selenium import webdriver
from selenium.webdriver.common.by import By
import time

def test_login(username, password):
    driver = webdriver.Chrome()
    driver.get("https://www.saucedemo.com/")

    driver.find_element(By.ID, "user-name").send_keys(username)
    driver.find_element(By.ID, "password").send_keys(password)
    driver.find_element(By.ID, "login-button").click()

    time.sleep(2)
    if "inventory.html" in driver.current_url:
        print(f"PASS: Login succeeded for user '{username}'")
    else:
        print(f"FAIL: Login failed for user '{username}'")

    driver.quit()

if __name__ == "__main__":
    print("Running positive test case:")
    test_login("standard_user", "secret_sauce")

    print("\nRunning negative test cases:")
    test_login("standard_user", "wrong_password")
    test_login("locked_out_user", "secret_sauce")
    test_login("", "")
