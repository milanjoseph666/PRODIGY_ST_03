# Automated Login Test for SauceDemo

## Description
Automated login test suite for [https://www.saucedemo.com/](https://www.saucedemo.com/) using Selenium in Python.

## Requirements
- Python 3.x
- Selenium (`pip install selenium`)
- ChromeDriver

## How to Run
1. Make sure ChromeDriver is installed and in your PATH.
2. Run the script with:
```bash
python test_login_saucedemo.py
```

## Test Cases
- ✅ Valid login (standard_user / secret_sauce)
- ❌ Invalid password (standard_user / wrong_password)
- ❌ Locked out user (locked_out_user / secret_sauce)
- ❌ Empty fields
